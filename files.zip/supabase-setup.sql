-- KORAK 1: Pokrenite ovaj SQL u Supabase SQL Editoru
-- Supabase → SQL Editor → New query → paste → Run

-- Tablica projekata
create table if not exists projekti (
  id bigserial primary key,
  naziv text not null,
  lokacija text not null,
  tip text not null default 'Nadzor',
  vrijednost numeric,
  investitor text,
  od text,
  do text,
  inzenjeri text[] default '{}',
  napomena text,
  created_at timestamptz default now()
);

-- Tablica inženjera
create table if not exists inzenjeri (
  id bigserial primary key,
  ime text not null unique,
  created_at timestamptz default now()
);

-- Dozvole za čitanje i pisanje (RLS - Row Level Security)
-- Opcija A: Otvoreni pristup (jednostavno, za internu upotrebu)
alter table projekti enable row level security;
alter table inzenjeri enable row level security;

create policy "Svi mogu čitati projekte" on projekti for select using (true);
create policy "Svi mogu pisati projekte" on projekti for insert with check (true);
create policy "Svi mogu ažurirati projekte" on projekti for update using (true);
create policy "Svi mogu brisati projekte" on projekti for delete using (true);

create policy "Svi mogu čitati inženjere" on inzenjeri for select using (true);
create policy "Svi mogu pisati inženjere" on inzenjeri for insert with check (true);
create policy "Svi mogu brisati inženjere" on inzenjeri for delete using (true);
