# UPUTA ZA POSTAVLJANJE BAZE REFERENCI
## Korak po korak — ukupno ~45 minuta

---

## KORAK 1 — Supabase (baza podataka)
**Trajanje: ~10 min**

1. Idi na https://supabase.com
2. Klikni "Start your project" → prijavi se s Google računom
3. Klikni "New project"
   - Organization: ostavi kao je
   - Name: `reference-baza` (ili bilo što)
   - Database Password: upiši nešto i ZAPAMTI (npr. spremi u Notes)
   - Region: odaberi `EU West` ili `EU Central`
4. Klikni "Create new project" — čekaj 1-2 minute da se stvori

5. Kad je spreman, idi na: **SQL Editor** (u lijevom izborniku)
6. Klikni "New query"
7. Otvori datoteku `supabase-setup.sql` (koju si dobio zajedno s ovim uputama)
8. Kopiraj CIJELI sadržaj i paste u SQL Editor
9. Klikni **"Run"** — trebao bi vidjeti "Success"

---

## KORAK 2 — Dohvati API podatke
**Trajanje: ~2 min**

1. U Supabase, idi na **Settings** (ikona zupčanika, lijevo dolje)
2. Klikni **API**
3. Pronađi i kopiraj negdje:
   - **Project URL** — izgleda kao: `https://abcdefghijk.supabase.co`
   - **anon public key** — dugački JWT token koji počinje sa `eyJ...`

---

## KORAK 3 — GitHub (pohrana koda)
**Trajanje: ~5 min**

1. Idi na https://github.com i napravi account ako nemaš
2. Klikni **"+"** (gore desno) → **"New repository"**
   - Repository name: `reference-baza`
   - Vidljivost: Private (preporučeno) ili Public
   - Klikni "Create repository"
3. Na novoj stranici, klikni **"uploading an existing file"**
4. Prevuci datoteku `index.html` u prozor
5. Klikni **"Commit changes"**

---

## KORAK 4 — Netlify (hosting, objava na web)
**Trajanje: ~5 min**

1. Idi na https://netlify.com
2. Klikni "Sign up" → prijavi se s GitHub računom
3. Klikni **"Add new site"** → **"Import an existing project"**
4. Odaberi **GitHub**
5. Pronađi i odaberi repo `reference-baza`
6. Sve ostavi kao je → klikni **"Deploy site"**
7. Za 30 sekundi, Netlify ti daje link kao:
   `https://amazing-name-123.netlify.app`

8. (Opcionalno) Za bolji URL: Site settings → Domain management → Add custom domain

---

## KORAK 5 — Prvo pokretanje
**Trajanje: ~3 min**

1. Otvori link koji ti je dao Netlify
2. Vidjet ćeš ekran za konfiguraciju — upiši:
   - **Supabase URL**: onaj `https://abcde.supabase.co` iz Koraka 2
   - **Supabase Key**: onaj `eyJ...` token iz Koraka 2
   - **Naziv firme**: ime vaše firme
3. Klikni **"Spoji na bazu"**
4. Aplikacija se otvara!

---

## DIJELJENJE S KOLEGAMA

Link koji ti je dao Netlify možeš poslati svim kolegama.
Svi rade na ISTOJ bazi — nema sinkronizacije, nema backup problema.

Primjer linka: `https://reference-baza-ime.netlify.app`

---

## ČESTA PITANJA

**Mogu li koristiti na mobitelu?**
Da, aplikacija radi na svim uređajima.

**Što ako netko slučajno obriše podatak?**
Supabase čuva backup automatski (zadnjih 7 dana na besplatnom planu).

**Je li besplatno?**
Da. Supabase besplatni plan: do 500 MB podataka i 50.000 zahtjeva/dan — za 14 inženjera i stotine projekata to je više nego dovoljno. Netlify besplatni plan: neograničeno za statičke stranice.

**Tko može pristupiti bazi?**
Samo onaj tko ima link. Nema prijave korisnika. Ako želite login, to se može dodati kasnije.

---

## AKO ZAPNETE

Javite se s točnim opisom gdje ste stali i što piše na ekranu.
